package br.academia.entidades;



import javax.persistence.*;

@Entity
@Table(name="aparelhos")
@NamedQueries({
	@NamedQuery(name="Aparelho.todos", 
		query="SELECT a FROM Aparelho a"),
	@NamedQuery(name="Aparelho.todosPorNome", 
		query="SELECT a FROM Aparelho a ORDER BY a.nome"),
	@NamedQuery(name="Aparelho.todosPorNomeContendo", 
	query="SELECT a FROM Aparelho a WHERE a.nome LIKE :termo ORDER BY a.nome")	
})

public class Aparelho {
	
	@Id
	private Integer codigo;
	
	@Column(length=50 )
	private String nome;
	
	@Column(length=50)
	private String descricao;
	
	@Column(length=50)
	private String marca;
	
	 public Integer getCodigo() {
	        return codigo;
	    }

	    public void setCodigo(Integer codigo) {
	        this.codigo = codigo;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }

	    public String getDescricao() {
	        return descricao;
	    }

	    public void setDescricao(String descricao) {
	        this.descricao = descricao;
	    }

	    public String getMarca() {
	        return marca;
	    }

	    public void setMarca(String marca) {
	        this.marca = marca;
	    }
		public String toString() {
			return String.format("Aparelho [codigo=%d, "
					+ "nome=\"%s\", "
					+ "descricao=\"%s\", "
					+ "marca=\"%s\" ]", 
					codigo, 
					nome,
					descricao,
					marca);
		}


}