package br.academia.entidades;
import javax.persistence.*;



@Entity
@Table(name="exercicios")
@NamedQueries({
	@NamedQuery(name="Exercicio.todos", 
			query="SELECT a FROM Exercicio a"),
	@NamedQuery(name="Exercicio.todosPorNome", 
	query="SELECT a FROM Exercicio a ORDER BY a.nome"),
	@NamedQuery(name="Exercicio.todosPorNomeContendo", 
	query="SELECT a FROM Exercicio a WHERE a.nome LIKE :termo ORDER BY a.nome")	
})
public class Exercicio {


	@Id
	private Integer codigo;

	@Column(nullable=false, length=200)
	private String descricao;

	@Column(length=50 )
	private String nome;

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="aparelho_fk")
	private Aparelho  aparelho;

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	public Aparelho getAparelho() {
		return aparelho;
	}

	public void setAparelho(Aparelho aparelho) {
		this.aparelho = aparelho;
	}
	public String toString() {
		return String.format("Exercicio [codigo=%d, "
				+ "descricao=\"%s\", "
				+ "nome=\"%s\", "
				+ "aparelho=\"%s\"]", 
				codigo, 
				descricao,
				nome,
				aparelho.toString());
	}


}