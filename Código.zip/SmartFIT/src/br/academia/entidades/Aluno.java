package br.academia.entidades;

import javax.persistence.*;

@Entity
@Table(name="alunos")
@NamedQueries({
	@NamedQuery(name="Aluno.todos", 
		query="SELECT a FROM Aluno a"),
	@NamedQuery(name="Aluno.todosPorNome", 
		query="SELECT a FROM Aluno a ORDER BY a.nome"),
	@NamedQuery(name="Aluno.todosPorNomeContendo", 
		query="SELECT a FROM Aluno a WHERE a.nome LIKE :termo ORDER BY a.nome")	
})
public class Aluno {

	@Id
	private long matricula;
	@Column(nullable=false, length=50)
	private String nome;
	@Column(length=11)
	private String fone;
	@Column(length=60)
	private String endereco;
	@Column(length=8)
	private String cep;
	@Column(length=1)
	private String sexo; 

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="curso_fk")
	private Curso curso;
	
	public long getMatricula() {
		return matricula;
	}

	public void setMatricula(long matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone.replaceAll("[^0-9]", "");
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep.replaceAll("[^0-9]", "");
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public String toString() {
		return String.format("Aluno [matricula=%d, "
				+ "nome=\"%s\", "
				+ "fone=\"%s\", "
				+ "endereco=\"%s\", "
				+ "cep=\"%s\", "
				+ "sexo=\"%s\", curso=%s]", 
				matricula, 
				nome,
				fone,
				endereco,
				cep,
				sexo, 
				curso.toString());
	}
	
}
