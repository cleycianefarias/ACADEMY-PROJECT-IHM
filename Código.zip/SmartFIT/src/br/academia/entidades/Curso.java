package br.academia.entidades;

import javax.persistence.*;

@Entity
@Table(name="cursos")
@NamedQueries({
	@NamedQuery(name="Curso.todos", 
		query="SELECT c FROM Curso c"),
	@NamedQuery(name="Curso.todosPorNome", 
		query="SELECT c FROM Curso c ORDER BY c.nome"),
	@NamedQuery(name="Curso.todosPorNomeContendo", 
		query="SELECT c FROM Curso c WHERE c.nome LIKE :termo ORDER BY c.nome")	
})
public class Curso {

	@Id
	private int codigo;
	@Column(nullable=false, length=50)
	private String nome;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String toString() {
		return String.format("Curso [codigo=%d, nome=\"%s\"]", 
				codigo, nome);
	}
	
}
