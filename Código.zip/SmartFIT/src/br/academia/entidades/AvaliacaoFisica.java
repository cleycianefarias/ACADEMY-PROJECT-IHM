package br.academia.entidades;
import javax.persistence.*;

@Entity
@Table(name="avaliacoesfisicas")
@NamedQueries({
	@NamedQuery(name="AvaliacaoFisica.todos", 
			query="SELECT a FROM AvaliacaoFisica a"),
	@NamedQuery(name="AvaliacaoFisica.todosPorNome", 
	query="SELECT a FROM AvaliacaoFisica a ORDER BY a.nome"),
	@NamedQuery(name="AvaliacaoFisica.todosPorNomeContendo", 
	query="SELECT a FROM AvaliacaoFisica a WHERE a.nome LIKE :termo ORDER BY a.nome")	
})
public class AvaliacaoFisica {

	@Id
	private int codigo;
	@Column(length=50 )
	private String nome;

	@Column(nullable=false)
	private double peso;

	@Column(nullable=false)
	private double altura;

	@Column(nullable=false)
	private double medidaTorax;

	@Column(nullable=false)
	private double medidaQuadril;

	@Column(nullable=false)
	private double medidaBracoDir;

	@Column(nullable=false)
	private double medidaBracoesq;

	@Column(nullable=false)
	private double medidaCoxaDir;

	@Column(nullable=false)
	private double medidaCoxaEsq;

	@Column(nullable=false)
	private double medidaAbdominal;

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="funcionario_fk")
	private Funcionario funcionario;
	
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="professor_fk")
	private Professor professor;


	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="aluno_fk")
	private Aluno aluno;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public double getMedidaTorax() {
		return medidaTorax;
	}

	public void setMedidaTorax(double medidaTorax) {
		this.medidaTorax = medidaTorax;
	}

	public double getMedidaQuadril() {
		return medidaQuadril;
	}

	public void setMedidaQuadril(double medidaQuadril) {
		this.medidaQuadril = medidaQuadril;
	}

	public double getMedidaBracoDir() {
		return medidaBracoDir;
	}

	public void setMedidaBracoDir(double medidaBracoDir) {
		this.medidaBracoDir = medidaBracoDir;
	}

	public double getMedidaBracoesq() {
		return medidaBracoesq;
	}

	public void setMedidaBracoesq(double medidaBracoesq) {
		this.medidaBracoesq = medidaBracoesq;
	}

	public double getMedidaCoxaDir() {
		return medidaCoxaDir;
	}

	public void setMedidaCoxaDir(double medidaCoxaDir) {
		this.medidaCoxaDir = medidaCoxaDir;
	}

	public double getMedidaCoxaEsq() {
		return medidaCoxaEsq;
	}

	public void setMedidaCoxaEsq(double medidaCoxaEsq) {
		this.medidaCoxaEsq = medidaCoxaEsq;
	}

	public double getMedidaAbdominal() {
		return medidaAbdominal;
	}

	public void setMedidaAbdominal(double medidaAbdominal) {
		this.medidaAbdominal = medidaAbdominal;
	}


	public Funcionario getFuncionario() {
		return funcionario;
	}
	
	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	
	public Professor getProfessor() {
		return professor;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}


	public String toString() {
		return String.format("AvaliacaoFisica [codigo=%d, "
				+ "nome=\"%s\", "
				+ "aluno=\"%s\", "
				+ "funcionario=\"%s\", "
				+ "professor=\"%s\", "
				+ "peso=%f, "
				+ "altura=%f, "
				+ "medidaTorax=%f, "
				+ "medidaQuadril=%f, "
				+ "medidaBracoDir= %f, "
				+ "medidaBracoesq= %f, "
				+ "medidaCoxaDir= %f, "
				+ "medidaCoxaEsq= %f, "
				+ "medidaAbdominal= %f, "
				+ "]", 
				codigo, 
				nome,
				aluno.toString(),
				funcionario.toString(),
				professor.toString(),
				peso,
				altura, 
				medidaTorax,
				medidaQuadril,
				medidaBracoDir,
				medidaCoxaEsq,
				medidaCoxaDir,
				medidaCoxaEsq,
				medidaAbdominal);
	}
}