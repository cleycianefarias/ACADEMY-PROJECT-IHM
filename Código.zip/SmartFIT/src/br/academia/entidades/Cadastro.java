package br.academia.entidades;

import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name="cadastros")
@NamedQueries({
	@NamedQuery(name="Cadastro.todos", 
			query="SELECT c FROM Cadastro c"),
	@NamedQuery(name="Cadastro.todosPorAluno", 
	query="SELECT c FROM Cadastro c ORDER BY c.nome"),
	@NamedQuery(name="Cadastro.todosPorNomeContendo", 
	query="SELECT c FROM Cadastro c WHERE c.nome LIKE :termo ORDER BY c.nome")	

})
public class Cadastro {

	@Id
	private Integer codigo;
	@Column(nullable=false, length=50)
	private String nome;


	@Column(nullable=false)
	private int duracao;
	
	@Column(length=11)
	private String datadeinicio;
	
	@Column(length=11)
	private String datadevencimento;

	@Column(nullable=false)
	private double valor;


	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="aluno_fk")
	private Aluno aluno;

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="funcionario_fk")
	private Funcionario funcionario;
	
	@OneToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="plano_fk")
	private Plano plano;

	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	public Aluno getAluno() {
		return aluno;	
	}
	public void setAluno(Aluno aluno) {
		this.aluno= aluno;
	}

	public String toString() {
		return String.format("Cadastro [codigo=%d, "
				+ "duracao= %d, "
				+ "datadeinicio=\"%s\", "
				+ "datadevencimento=\"%s\", "
				+ "valor= %f, "
				+ "aluno=\"%s\", "
				+ "funcionario=\"%s\""
				+ "plano=\"%s\"]", 
				codigo, 
				duracao,
				datadeinicio,
				datadevencimento,
				valor,
				aluno.toString(),
				funcionario.toString(),
				plano.toString());
	}
	public String getDatadevencimento() {
		return datadevencimento;
	}
	public void setDatadevencimento(String datadevencimento) {
		this.datadevencimento = datadevencimento;
	}
	public String getDatadeinicio() {
		return datadeinicio;
	}
	public void setDatadeinicio(String datadeinicio) {
		this.datadeinicio = datadeinicio;
	}
	public Plano getPlano() {
		return plano;
	}
	public void setPlano(Plano plano) {
		this.plano = plano;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

}