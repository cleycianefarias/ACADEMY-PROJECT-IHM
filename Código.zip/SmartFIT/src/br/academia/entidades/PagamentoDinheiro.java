package br.academia.entidades;

import java.util.*;

import javax.persistence.*;

@Entity
@Table(name="pagamentoDinheiro")
@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="TIPO")
@NamedQueries({
	@NamedQuery(name="PagamentoDinheiro.todos", 
			query="SELECT a FROM PagamentoDinheiro a"),
	@NamedQuery(name="PagamentoDinheiro.todosPorNome", 
	query="SELECT a FROM PagamentoDinheiro a ORDER BY a.nome"),
	@NamedQuery(name="PagamentoDinheiro.todosPorNomeContendo", 
	query="SELECT a FROM PagamentoDinheiro a WHERE a.nome LIKE :termo ORDER BY a.nome")	

})

public class PagamentoDinheiro {

	@Id
	private long codigo;
	@Column(nullable=false, length=50)
	private String nome;
	@Column(nullable=false)
	private double valor;
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="Cadastro_fk")
	private Cadastro cadastro;
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="Aluno_fk")
	private Aluno aluno;
	public long getCodigo() {
		return codigo;
	}
	public void setCodigo(long codigo) {
		this.codigo = codigo;
	}
	public double getValor() {
		return valor;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}


	public Cadastro getCadastro() {
		return cadastro;
	}
	public void setCadastro(Cadastro cadastro) {
		this.cadastro = cadastro;
	}

	public String toString() {
		return String.format("PagamentoDinheiro [codigo=%d, "
				+ "aluno=\"%s\", "
				+ "pacote=\"%s\", "
				+ "valor=%d, "
				+ "]", 
				codigo, 
				aluno.toString(),
				cadastro.toString(),
				valor);
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	

}