package br.academia.entidades;
import javax.persistence.*;


@Entity
@Table(name="series")
@NamedQueries({
	@NamedQuery(name="Serie.todos", 
			query="SELECT s FROM Serie s"),
	@NamedQuery(name="Serie.todosPorNome", 
	query="SELECT s FROM Serie s ORDER BY s.nome"),
	@NamedQuery(name="Serie.todosPorNomeContendo", 
	query="SELECT a FROM Serie a WHERE a.nome LIKE :termo ORDER BY a.nome")	

})

public class Serie {
	@Id
	private int codigo;
	@Column(nullable=false)
	private int repeticoes;
	@Column(length=50 )
	private String nome;

	// rever a serie e o treino
	
	@ManyToOne(cascade={CascadeType.MERGE})
	@JoinColumn(name="treino_fk")
	private Treino treino;
	
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="exercicio_fk")
	private Exercicio exercicio;



	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getRepeticoes() {
		return repeticoes;
	}

	public void setRepeticoes(int repeticoes) {
		this.repeticoes = repeticoes;
	}

	public Exercicio getExercicio() {
		return exercicio;
	}

	public void setExercicio(Exercicio exercicio) {
		this.exercicio = exercicio;
	}

	public Treino getTreino() {
		return treino;
	}

	public void setTreino(Treino treino) {
		this.treino=treino;
	}

	public String toString() {
		return String.format("Serie [codigo=%d, "
				+ "treino=\"%s\", "
				+ "repeticoes=\"%s\", "
				+ "nome=\"%s\", "
				+ "exercicio=\"%s\"]", 
				codigo, 
				treino.toString(),
				repeticoes,
				nome,
				exercicio.toString());
	}
}