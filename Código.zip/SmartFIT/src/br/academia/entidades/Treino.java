package br.academia.entidades;
import javax.persistence.*;



@Entity
@Table(name="treinos")
@NamedQueries({
	@NamedQuery(name="Treino.todos", 
			query="SELECT c FROM Treino c"),
	@NamedQuery(name="Treino.todosPorNome", 
	query="SELECT c FROM Treino c ORDER BY c.nome"),
	@NamedQuery(name="Treino.todosPorNomeContendo", 
	query="SELECT a FROM Treino a WHERE a.nome LIKE :termo ORDER BY a.nome")	

})
public class Treino {

	@Id
	private int codigo;

	@Column(nullable=false, length=50)
	private String nome;

	@Column(nullable=false, length=50)
	private String periodo;


	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="funcionario_fk")
	public Funcionario funcionario;

	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="aluno_fk")
	public Aluno  aluno;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario=funcionario;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public String toString() {
		return String.format("Treino [codigo=%d, "
				+ "nome=\"%s\", "
				+ "periodo=\"%s\", "
				+ "funcionario=\"%s\", "
				+ "aluno=\"%s\"]", 
				codigo, 
				nome,
				periodo,
				funcionario.toString(),
				aluno.toString());
	}
	

}