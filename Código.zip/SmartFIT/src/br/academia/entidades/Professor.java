package br.academia.entidades;
import java.util.*;

import javax.persistence.*;

@Entity
@Table(name="professores")
@NamedQueries({
	@NamedQuery(name="Professor.todos", 
			query="SELECT f FROM Professor f"),
	@NamedQuery(name="Professor.todosPorNome", 
	query="SELECT f FROM Professor f ORDER BY f.nome"),
	@NamedQuery(name="Professor.todosPorNomeContendo", 
	query="SELECT a FROM Professor a WHERE a.nome LIKE :termo ORDER BY a.nome")	
})

public class Professor {
	@Id
	private long matricula;

	@Column(length=50)
	private String nome;

	@Column(length=11)
	private String cpf;

	@Column(length=10)
	private String rg;

	@Column(length=50)
	private String endereco;


	@Column(length=50)
	private String email;

	@Column(nullable=false)
	private double salario;

//	private Date nascimento;


	public long getMatricula() {
		return matricula;
	}

	public void setMatricula( long matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf.replaceAll("[^0-9]", "");
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

//	public Date getNascimento() {
//		return nascimento;
//	}
//
//	public void setNascimento(Date nascimento) {
//		this.nascimento = nascimento;
//	}

	public String toString() {
		return String.format("Professor [matricula %d, "
				+ "nome=\"%s\", "
				+ "cpf=\"%s\", "
				+ "rg=\"%s\", "
				+ "endereco=\"%s\", "
				+ "email=\"%s\", "
				+ "salario= %f]",
				matricula, 
				nome,
				cpf,
				rg,
				endereco,
				email,
				salario);
	}


}