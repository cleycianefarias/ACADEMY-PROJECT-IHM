package br.academia.entidades;
import javax.persistence.*;


@Entity
@Table(name="planos")

@NamedQueries({
	@NamedQuery(name="Plano.todos", 
			query="SELECT p FROM Plano p"),
	@NamedQuery(name="Plano.todosPorNome", 
	query="SELECT p FROM Plano p ORDER BY p.nome"),
	@NamedQuery(name="Plano.todosPorNomeContendo", 
	query="SELECT p FROM Plano p WHERE p.nome LIKE :termo ORDER BY p.nome")	
})
public class Plano {

	@Id
	private Integer codigo;

	@Column(nullable=false, length=50)
	private String nome;

	@Column(nullable=false, length=50)
	private String descricao;

	@Column(nullable=false)
	private double valor;
	
//	@OneToMany(cascade=CascadeType.MERGE)
//	@JoinColumn(name="Exercicios_fk")
//	private List <Exercicio> exercicios;

	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}

//	public List <Exercicio> getExercicios() {
//		return exercicios;
//	}
//	public void setExercicios(List <Exercicio> exercicios) {
//		this.exercicios = exercicios;
//	}


	public String toString() {
		return String.format("Pacote [codigo=%d, "
				+ "nome=\"%s\", "
				+ "descricao=\"%s\", "
				+ "duracao=\"%s\", "
				+ "valor=%f]", 
				codigo, 
				nome,
				descricao,
				valor);
			
	}

}