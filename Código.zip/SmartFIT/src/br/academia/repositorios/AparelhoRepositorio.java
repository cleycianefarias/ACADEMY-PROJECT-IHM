package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class AparelhoRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public AparelhoRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Aparelho aparelho) {
		em.getTransaction().begin();
		em.persist(aparelho);
		em.getTransaction().commit();
	}

	public Aparelho recuperar(int codigo) {
		return em.find(Aparelho.class, codigo);
	}

	public void atualizar(Aparelho aparelho) {
		em.getTransaction().begin();
		em.merge(aparelho);
		em.getTransaction().commit();
	}

	public void remover(Aparelho aparelho) {
		em.getTransaction().begin();
		em.remove(aparelho);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<Aparelho> recuperarTodos(){
		return em.createNamedQuery("Aparelho.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Aparelho> recuperarTodosPorNome(){
		return em.createNamedQuery("Aparelho.todosPorNome").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Aparelho> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Aparelho.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}
	public void encerrar() {
		em.close();
		emf.close();
	}

}