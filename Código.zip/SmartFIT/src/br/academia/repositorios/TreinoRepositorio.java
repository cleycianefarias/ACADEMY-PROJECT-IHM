package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;
public class TreinoRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public TreinoRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Treino treino) {
		em.getTransaction().begin();
		em.persist(treino);
		em.getTransaction().commit();
	}

	public Treino recuperar(int codigo) {
		return em.find(Treino.class, codigo);
	}

	public void atualizar(Treino treino) {
		em.getTransaction().begin();
		em.merge(treino);
		em.getTransaction().commit();
	}

	public void remover(Treino treino) {
		em.getTransaction().begin();
		em.remove(treino);
		em.getTransaction().commit();		
	}
	
	@SuppressWarnings("unchecked")
	public List<Treino> recuperarTodos(){
		return em.createNamedQuery("Treino.todos").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Treino> recuperarTodosPorNome(){
		return em.createNamedQuery("Treino.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Treino> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Treino.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}
	public void encerrar() {
		em.close();
		emf.close();
	}

}