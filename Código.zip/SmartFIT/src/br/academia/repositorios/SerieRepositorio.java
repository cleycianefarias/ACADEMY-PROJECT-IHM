package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;
public class SerieRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public SerieRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Serie serie) {
		em.getTransaction().begin();
		em.persist(serie);
		em.getTransaction().commit();
	}

	public Serie recuperar(int codigo) {
		return em.find(Serie.class, codigo);
	}

	public void atualizar(Serie serie) {
		em.getTransaction().begin();
		em.merge(serie);
		em.getTransaction().commit();
	}

	public void remover(Serie serie) {
		em.getTransaction().begin();
		em.remove(serie);
		em.getTransaction().commit();		
	}
	
	@SuppressWarnings("unchecked")
	public List<Serie> recuperarTodos(){
		return em.createNamedQuery("Serie.todos").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Serie> recuperarTodosPorNome(){
		return em.createNamedQuery("Serie.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Serie> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Serie.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}
	
	public void encerrar() {
		em.close();
		emf.close();
	}

}