package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class CadastroRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public CadastroRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Cadastro cadastro) {
		em.getTransaction().begin();
		em.persist(cadastro);
		em.getTransaction().commit();
	}

	public Cadastro recuperar(long matricula) {
		return em.find(Cadastro.class, matricula);
	}

	public void atualizar(Cadastro cadastro) {
		em.getTransaction().begin();
		em.merge(cadastro);
		em.getTransaction().commit();
	}

	public void remover(Cadastro cadastro) {
		em.getTransaction().begin();
		em.remove(cadastro);
		em.getTransaction().commit();		
	}
	
	@SuppressWarnings("unchecked")
	public List<Cadastro> recuperarTodos(){
		return em.createNamedQuery("Cadastro.todos").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Cadastro> recuperarTodosPorAluno(){
		return em.createNamedQuery("Cadastro.todosPorAluno").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Cadastro> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Cadastro.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	public void encerrar() {
		em.close();
		emf.close();
	}

}