package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class PagamentoDinheiroRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public PagamentoDinheiroRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(PagamentoDinheiro pagamentoDinheiro) {
		em.getTransaction().begin();
		em.persist(pagamentoDinheiro);
		em.getTransaction().commit();
	}

	public PagamentoDinheiro recuperar(long codigo) {
		return em.find(PagamentoDinheiro.class, codigo);
	}

	public void atualizar(PagamentoDinheiro pagamentoDinheiro) {
		em.getTransaction().begin();
		em.merge(pagamentoDinheiro);
		em.getTransaction().commit();
	}

	public void remover(PagamentoDinheiro pagamentoDinheiro) {
		em.getTransaction().begin();
		em.remove(pagamentoDinheiro);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<PagamentoDinheiro> recuperarTodos(){
		return em.createNamedQuery("PagamentoDinheiro.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<PagamentoDinheiro> recuperarTodosPorNome(){
		return em.createNamedQuery("PagamentoDinheiro.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<PagamentoDinheiro> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("PagamentoDinheiro.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}
	public void encerrar() {
		em.close();
		emf.close();
	}

}