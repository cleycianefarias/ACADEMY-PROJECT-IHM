package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;
public class PlanoRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public PlanoRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Plano plano) {
		em.getTransaction().begin();
		em.persist(plano);
		em.getTransaction().commit();
	}

	public Plano recuperar(int codigo) {
		return em.find(Plano.class, codigo);
	}

	public void atualizar(Plano plano) {
		em.getTransaction().begin();
		em.merge(plano);
		em.getTransaction().commit();
	}

	public void remover(Plano plano) {
		em.getTransaction().begin();
		em.remove(plano);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<Plano> recuperarTodos(){
		return em.createNamedQuery("Plano.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Plano> recuperarTodosPorNome(){
		return em.createNamedQuery("Plano.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Plano> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Plano.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	public void encerrar() {
		em.close();
		emf.close();
	}

}