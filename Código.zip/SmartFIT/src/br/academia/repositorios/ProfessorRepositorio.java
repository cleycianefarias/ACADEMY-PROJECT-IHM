package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class ProfessorRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public ProfessorRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Professor professor) {
		em.getTransaction().begin();
		em.persist(professor);
		em.getTransaction().commit();
	}

	public Professor recuperar(long matricula) {
		return em.find(Professor.class, matricula);
	}

	public void atualizar(Professor professor) {
		em.getTransaction().begin();
		em.merge(professor);
		em.getTransaction().commit();
	}

	public void remover(Professor professor) {
		em.getTransaction().begin();
		em.remove(professor);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<Professor> recuperarTodos(){
		return em.createNamedQuery("Professor.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Professor> recuperarTodosPorNome(){
		return em.createNamedQuery("Professor.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Professor> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Professor.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	public void encerrar() {
		em.close();
		emf.close();
	}


}