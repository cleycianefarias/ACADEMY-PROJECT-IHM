package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class ExercicioRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public ExercicioRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Exercicio exercicio) {
		em.getTransaction().begin();
		em.persist(exercicio);
		em.getTransaction().commit();
	}

	public Exercicio recuperar(int codigo) {
		return em.find(Exercicio.class, codigo);
	}

	public void atualizar(Exercicio exercicio) {
		em.getTransaction().begin();
		em.merge(exercicio);
		em.getTransaction().commit();
	}

	public void remover(Exercicio exercicio) {
		em.getTransaction().begin();
		em.remove(exercicio);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<Exercicio> recuperarTodos(){
		return em.createNamedQuery("Exercicio.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Aparelho> recuperarTodosPorNome(){
		return em.createNamedQuery("Exercicio.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Exercicio> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Exercicio.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}


	public void encerrar() {
		em.close();
		emf.close();
	}

}