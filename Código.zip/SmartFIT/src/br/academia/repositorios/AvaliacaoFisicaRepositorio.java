package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class AvaliacaoFisicaRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public AvaliacaoFisicaRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(AvaliacaoFisica avaliacaoFisica) {
		em.getTransaction().begin();
		em.persist(avaliacaoFisica);
		em.getTransaction().commit();
	}

	public AvaliacaoFisica recuperar(int codigo) {
		return em.find(AvaliacaoFisica.class, codigo);
	}

	public void atualizar(AvaliacaoFisica avaliacaoFisica) {
		em.getTransaction().begin();
		em.merge(avaliacaoFisica);
		em.getTransaction().commit();
	}

	public void remover(AvaliacaoFisica avaliacaoFisica) {
		em.getTransaction().begin();
		em.remove(avaliacaoFisica);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<AvaliacaoFisica> recuperarTodos(){
		return em.createNamedQuery("AvaliacaoFisica.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<AvaliacaoFisica> recuperarTodosPorNome(){
		return em.createNamedQuery("AvaliacaoFisica.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<AvaliacaoFisica> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("AvaliacaoFisica.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	public void encerrar() {
		em.close();
		emf.close();
	}

}