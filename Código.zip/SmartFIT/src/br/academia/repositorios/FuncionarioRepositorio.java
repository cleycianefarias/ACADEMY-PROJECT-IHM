package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class FuncionarioRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public FuncionarioRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Funcionario funcionario) {
		em.getTransaction().begin();
		em.persist(funcionario);
		em.getTransaction().commit();
	}

	public Funcionario recuperar(long matricula) {
		return em.find(Funcionario.class, matricula);
	}

	public void atualizar(Funcionario funcionario) {
		em.getTransaction().begin();
		em.merge(funcionario);
		em.getTransaction().commit();
	}

	public void remover(Funcionario funcionario) {
		em.getTransaction().begin();
		em.remove(funcionario);
		em.getTransaction().commit();		
	}

	@SuppressWarnings("unchecked")
	public List<Funcionario> recuperarTodos(){
		return em.createNamedQuery("Funcionario.todos").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Funcionario> recuperarTodosPorNome(){
		return em.createNamedQuery("Funcionario.todosPorNome").getResultList();
	}
	@SuppressWarnings("unchecked")
	public List<Funcionario> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Funcionario.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	public void encerrar() {
		em.close();
		emf.close();
	}


}