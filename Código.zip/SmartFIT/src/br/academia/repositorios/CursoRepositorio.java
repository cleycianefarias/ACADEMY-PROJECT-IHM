package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class CursoRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public CursoRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Curso curso) {
		em.getTransaction().begin();
		em.persist(curso);
		em.getTransaction().commit();
	}

	public Curso recuperar(int codigo) {
		return em.find(Curso.class, codigo);
	}

	public void atualizar(Curso curso) {
		em.getTransaction().begin();
		em.merge(curso);
		em.getTransaction().commit();
	}

	public void remover(Curso curso) {
		em.getTransaction().begin();
		em.remove(curso);
		em.getTransaction().commit();		
	}
	
	@SuppressWarnings("unchecked")
	public List<Curso> recuperarTodos(){
		return em.createNamedQuery("Curso.todos").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Curso> recuperarTodosPorNome(){
		return em.createNamedQuery("Curso.todosPorNome").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Curso> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Curso.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}	
	
	public void encerrar() {
		em.close();
		emf.close();
	}

}
