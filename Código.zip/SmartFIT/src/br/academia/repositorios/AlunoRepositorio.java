package br.academia.repositorios;

import java.util.*;
import javax.persistence.*;

import br.academia.entidades.*;

public class AlunoRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;

	public AlunoRepositorio() {
		emf = Persistence.createEntityManagerFactory("AcademicoJPA");
		em = emf.createEntityManager();
	}

	public void adicionar(Aluno aluno) {
		em.getTransaction().begin();
		em.persist(aluno);
		em.getTransaction().commit();
	}

	public Aluno recuperar(long matricula) {
		return em.find(Aluno.class, matricula);
	}

	public void atualizar(Aluno aluno) {
		em.getTransaction().begin();
		em.merge(aluno);
		em.getTransaction().commit();
	}

	public void remover(Aluno aluno) {
		em.getTransaction().begin();
		em.remove(aluno);
		em.getTransaction().commit();		
	}
	
	@SuppressWarnings("unchecked")
	public List<Aluno> recuperarTodos(){
		return em.createNamedQuery("Aluno.todos").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Aluno> recuperarTodosPorNome(){
		return em.createNamedQuery("Aluno.todosPorNome").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Aluno> recuperarTodosPorNomeContendo(String termo){
		return em.createNamedQuery("Aluno.todosPorNomeContendo")
				.setParameter("termo", "%" + termo + "%")
				.getResultList();
	}

	
	public void encerrar() {
		em.close();
		emf.close();
	}

}
