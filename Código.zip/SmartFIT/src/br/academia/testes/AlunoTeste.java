//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//
//public class AlunoTeste {
//
//	public static void main(String[] args) {
//		
//		AlunoRepositorio ar = new AlunoRepositorio();
//		AvaliacaoFisicaRepositorio avr = new AvaliacaoFisicaRepositorio();
//		TreinoRepositorio tr = new TreinoRepositorio();
//		List<Aluno> alunos;
//		
//		Aluno a1,a2,a3;
//		Treino t1;
//		AvaliacaoFisica av1;
//		
//		av1 = avr.recuperar(1);
//		t1 = tr.recuperar(1);
//
//		a1 = new Aluno();
//		a1.setMatricula(1);
//		a1.setNome("Ziraldo da Zilva");
//		a1.setFone("9999");
//		a1.setEndereco("rua");
//		a1.setCep("9558");
//		a1.setSexo("f");
//		a2 = new Aluno();
//		a2.setMatricula(2);
//		a2.setNome("Adair Calore");
//		a2.setFone("9988");
//		a2.setEndereco("rua");
//		a2.setCep("45869");
//		a2.setSexo("M");
//		
//		a3 = new Aluno();
//		a3.setMatricula(3);
//		a3.setNome("Medusa");
//		a3.setFone("9949");
//		a3.setEndereco("rua");
//		a3.setCep("9588");
//		a3.setSexo("f");
//
//		System.out.println("Adicionando Alunos...");
//		ar.adicionar(a1);
//		ar.adicionar(a2);
//		ar.adicionar(a3);
//
//		System.out.println("Listando alunos, todos...");
//		alunos = ar.recuperarTodos();
//		for (Aluno aluno : alunos) {
//			System.out.println(aluno);
//		}
//
//		System.out.println("Recuperando aluno, id=1...");
//		a1 = ar.recuperar(1);
//		a1.setNome("Francisco Carlos de Oliveira");
//		a1.setSexo("M");
//
//		System.out.println("Atualizando aluno, id=1");
//		ar.atualizar(a1);
//		
//		System.out.println("Listando alunos, todos...");
//		alunos = ar.recuperarTodos();
//		for (Aluno aluno : alunos) {
//			System.out.println(aluno);
//		}
//		
////		System.out.println("Removendo alunos...");
////		alunos = ar.recuperarTodos();
////		for (Aluno aluno : alunos) {
////			ar.remover(aluno);
////		}
//
//		System.out.println("Listando alunos, nenhum...");
//		alunos = ar.recuperarTodos();
//		for (Aluno aluno : alunos) {
//			System.out.println(aluno);
//		}
//		
//		ar.encerrar();
//		avr.encerrar();
//		tr.encerrar();
//		
//	}
//
//}