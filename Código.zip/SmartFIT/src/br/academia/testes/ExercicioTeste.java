//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//public class ExercicioTeste {
//
//	public static void main(String[] args) {
//		ExercicioRepositorio  er = new ExercicioRepositorio();
//		AparelhoRepositorio ar= new AparelhoRepositorio();
//
//
//		List<Exercicio> exercicios;
//		Exercicio e1,e2 ,e3;
//		Aparelho a1;
//
//		a1=ar.recuperar(1);
//		System.out.println(a1.getNome());
//		e1 = new Exercicio();
//		e1.setAparelho(a1);
//		e1.setCodigo(1);
//		e1.setDescricao("1");
//
//
//
//		e2 = new Exercicio();
//		e2.setAparelho(a1);
//		e2.setCodigo(2);
//		e2.setDescricao("1");
//
//
//		e3 = new Exercicio();
//		e3.setAparelho(a1);
//		e3.setCodigo(3);
//		e3.setDescricao("1");
//		e3.setNome("Teste03");
//
//
//
//		System.out.println("Adicionando exercicios...");
//		er.adicionar(e1);
//		er.adicionar(e2);
//		er.adicionar(e3);
//		
//		System.out.println("Listando exercicios, todos...");
//		exercicios = er.recuperarTodos();
//		for (Exercicio exercicio : exercicios) {
//			System.out.println(exercicio);
//		}
//
//	
//		exercicios = er.recuperarTodos();
//		System.out.println("Recuperando exercicio, id=1..");
//		e1 = er.recuperar(1);
//		e1.setDescricao("23");
//
//		System.out.println("Atualizando exercicios, id=1");
//		ar.atualizar(a1);
//
//		System.out.println("Listando exercicios, todos...");
//		exercicios = er.recuperarTodos();
//		for (Exercicio exercicio : exercicios) {
//			System.out.println(exercicio);
//		}
//
////		System.out.println("Listando exercicios, todos...");
////		exercicios = er.recuperarTodos();
////		for (Exercicio exercicio : exercicios) {
////
////			er.remover(exercicio);
////		}
//
//
//
//		ar.encerrar();
//		er.encerrar();
//
//
//	}
//
//}