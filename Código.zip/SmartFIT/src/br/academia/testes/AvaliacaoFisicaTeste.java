//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//public class AvaliacaoFisicaTeste {
//
//	public static void main(String[] args) {
//
//		AvaliacaoFisicaRepositorio ar = new AvaliacaoFisicaRepositorio();
//		AlunoRepositorio alr = new AlunoRepositorio();
//		FuncionarioRepositorio fr = new FuncionarioRepositorio();
//
//
//		List<AvaliacaoFisica> avaliacaoFisicas;
//		Aluno al1;
//		//entidade professor
//		Funcionario f1;
//		
//		AvaliacaoFisica a1,a2,a3;
//		al1 = alr.recuperar(1);
//		f1 = fr.recuperar(1);
//
//		a1 = new AvaliacaoFisica();
//		a1.setCodigo(1);
//		a1.setAltura(1.48);
//		a1.setPeso(47);
//		a1.setMedidaTorax(32);
//		a1.setNome("Teste01");
//		a1.setMedidaQuadril(48);
//		a1.setMedidaBracoDir(20);
//		a1.setMedidaBracoesq(32);
//		a1.setMedidaCoxaDir(32);
//		a1.setMedidaCoxaEsq(35);
//		a1.setMedidaAbdominal(36);
//		a1.setAluno(al1);
//		a1.setFuncionario(f1);
//
//		a2 = new AvaliacaoFisica();
//		a2.setCodigo(3);
//		a2.setAltura(1.48);
//		a2.setPeso(47);
//		a2.setMedidaTorax(32);
//		a2.setNome("Teste02");
//		a2.setMedidaQuadril(48);
//		a2.setMedidaBracoDir(20);
//		a2.setMedidaBracoesq(32);
//		a2.setMedidaCoxaDir(32);
//		a2.setMedidaCoxaEsq(35);
//		a2.setMedidaAbdominal(36);
//		a2.setAluno(al1);
//		a2.setFuncionario(f1);
//
//
//		System.out.println("Adicionando avaliacoes Fisicas...");
//		ar.adicionar(a1);
//		ar.adicionar(a2);
//
//
//		System.out.println("Listando avaliacoes Fisicas, todos...");
//		avaliacaoFisicas = ar.recuperarTodos();
//		for (AvaliacaoFisica avaliacao : avaliacaoFisicas) {
//			System.out.println(avaliacao);
//		}
//		System.out.println("Recuperando avaliacao Fisica, id=1...");
//		a1 = ar.recuperar(1);
//		a1.setAltura(23);
//
//		System.out.println("Atualizando avaliacao Fisica, id=1");
//		ar.atualizar(a1);
//
//		System.out.println("Listando avaliacoes Fisicas, todos...");
//		avaliacaoFisicas = ar.recuperarTodos();
//		for (AvaliacaoFisica avaliacao : avaliacaoFisicas) {
//			System.out.println(avaliacao);
//		}
//
////		System.out.println("Listando avaliacoes Fisicas, todos...");
////		avaliacaoFisicas = ar.recuperarTodos();
////		for (AvaliacaoFisica avaliacao : avaliacaoFisicas) {
////
////			ar.remover(avaliacao);
////		}
//
//
//		avaliacaoFisicas = ar.recuperarTodos();
//		for (AvaliacaoFisica avaliacao : avaliacaoFisicas) {
//
//			System.out.println(avaliacao);
//		}
//
//		ar.encerrar();
//		alr.encerrar();
//		fr.encerrar();
//
//
//	}
//
//}