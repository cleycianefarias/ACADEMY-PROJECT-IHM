//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//public class TreinoTeste {
//
//	public static void main(String[] args) {
//
//		TreinoRepositorio tr = new TreinoRepositorio();
//		List<Treino>treinos;
//		SerieRepositorio sr = new SerieRepositorio();
//		AlunoRepositorio ar = new AlunoRepositorio();
//		FuncionarioRepositorio fr = new FuncionarioRepositorio();
//		List<Serie> s1;
//		Serie se2;
//		Treino t1,t2,t3;
//		Aluno a1,a2,a3;
//		Funcionario f1,f2,f3;
//
//		ExercicioRepositorio er = new ExercicioRepositorio();
//
//		s1= sr.recuperarTodos();
//		se2 = sr.recuperar(3);
//		s1.clear();
//		s1.add(se2);
//		a1 = ar.recuperar(1);
//		a2 = ar.recuperar(2);
//		a3 = ar.recuperar(3);
//
//		f1 = fr.recuperar(1);
//		f2 = fr.recuperar(2);
//		f3 = fr.recuperar(3);
//
//
//		t1 = new Treino();
//		t1.setCodigo(1);
//		t1.setNome("Perna");
//		t1.setPeriodo("2 meses");
//		t1.setAluno(a1);
//		t1.setFuncionario(f1);
//
//		t2 = new Treino();
//		t2.setCodigo(2);
//		t2.setNome("Adaptativo");
//		t2.setPeriodo("1 meses");
//		t2.setAluno(a2);
//		t2.setFuncionario(f2);
//
//		t3 = new Treino();
//		t3.setCodigo(3);
//		t3.setNome("Braço");
//		t3.setPeriodo("2 meses");
//		t3.setAluno(a3);
//		t3.setFuncionario(f3);
//
//
//
//		tr.adicionar(t1);
//		tr.adicionar(t2);
//
//		tr.adicionar(t3);
//
//		System.out.println("Listando alunos, todos...");
//		treinos = tr.recuperarTodos();
//		for (Treino treino : treinos) {
//			System.out.println(treino);
//		}
//
//		System.out.println("Listando alunos, todos...");
//		treinos = tr.recuperarTodos();
//		System.out.println("Recuperando aluno, id=444...");
//		t1 = tr.recuperar(1);
//		t1.setPeriodo("4 meses");
//
//		System.out.println("Atualizando aluno, id=444");
//		tr.atualizar(t1);
//
//		System.out.println("Listando alunos, todos...");
//		treinos = tr.recuperarTodos();
//		for (Treino treino : treinos) {
//			System.out.println(treino);
//		}
//
////		System.out.println("Listando alunos, todos...");
////		treinos = tr.recuperarTodos();
////		for (Treino treino : treinos) {
////			tr.remover(treino);
////		}
//
//
//		System.out.println("Listando alunos, todos...");
//		treinos = tr.recuperarTodos();
//		for (Treino treino : treinos) {
//			System.out.println(treino);
//		}
//
//		tr.encerrar();
//		sr.encerrar();
//		ar.encerrar();
//		fr.encerrar();
//
//
//	}
//
//}