//package br.academia.testes;
//
//import java.text.ParseException;
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//
//public class FuncionarioTeste {
//
//	public static void main(String[] args) throws ParseException {
//		
//		FuncionarioRepositorio fr = new FuncionarioRepositorio();
//		List<Funcionario> funcionarios;
//		
//
//		Date d1,d2,d3;
//		Funcionario f1,f2,f3;
//	
//		
//		f1 = new Funcionario();
//		f1.setMatricula(1);
//		f1.setNome("Florentina da Zilva");
//		f1.setCpf("12345678912");
//		f1.setRg("12345");
//		f1.setEndereco("Bosque");
//		f1.setTelefone("99999");
//		f1.setEmail("email");
//		f1.setSalario(256);
//		f1.setNascimento(d1 = new Date());
//
//		f2 = new Funcionario();
//		f2.setMatricula(2);
//		f2.setNome("Seu Zé da Silva");
//		f2.setCpf("12345678910");
//		f2.setRg("12346");
//		f2.setEndereco("Bairo da Paz");
//		f2.setTelefone("88888");
//		f2.setEmail("email");
//		f2.setSalario(1253);
//		f2.setNascimento(d2 = new Date());
//		
//		f3 = new Funcionario();
//		f3.setMatricula(3);
//		f3.setNome("Maven Calore");
//		f3.setCpf("12345678914");
//		f3.setRg("12348");
//		f3.setEndereco("Palafitas");
//		f3.setTelefone("999999");
//		f3.setEmail("email");
//		f3.setSalario(654);
//		f3.setNascimento(d3 = new Date());
//		
//		System.out.println("Adicionando funcionarios...");
//		fr.adicionar(f1);
//		fr.adicionar(f2);
//		fr.adicionar(f3);
//
//		System.out.println("Listando funcionarios, todos...");
//		funcionarios = fr.recuperarTodos();
//		for (Funcionario funcionario : funcionarios) {
//			System.out.println(funcionario);
//		}
//
//		System.out.println("Recuperando funcionario, id=1...");
//		f1 = fr.recuperar(1);
//		f1.setNome("Lanore");
//		f1.setCpf("12345678000");
//		f1.setRg("12000");
//		f1.setEndereco("BosqueB");
//		f1.setTelefone("999991");
//		f1.setEmail("email");
//		f1.setSalario(256);
//		f1.setNascimento(d1 = new Date());
//		
//		System.out.println("Atualizando funcionario, id=1");
//		fr.atualizar(f1);
//		
//		System.out.println("Listando funcionarios, todos...");
//		funcionarios = fr.recuperarTodos();
//		for (Funcionario funcionario : funcionarios) {
//			System.out.println(funcionario);
//		}
//		
////		System.out.println("Removendo funcionarios...");
////		funcionarios = fr.recuperarTodos();
////		for (Funcionario funcionario : funcionarios) {
////		fr.remover(funcionario);
////		}
//
//		System.out.println("Listando funcionarios, nenhum...");
//		funcionarios = fr.recuperarTodos();
//		for (Funcionario funcionario : funcionarios) {
//			System.out.println(funcionario);
//		}
//		
//		fr.encerrar();
//		
//	}
//
//}