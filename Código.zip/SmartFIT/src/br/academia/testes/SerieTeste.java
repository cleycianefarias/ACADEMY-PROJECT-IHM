//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//public class SerieTeste {
//
//	public static void main(String[] args) {
//		ExercicioRepositorio er = new ExercicioRepositorio();
//		SerieRepositorio sr = new SerieRepositorio();
//		TreinoRepositorio tr = new TreinoRepositorio();
//		List<Serie>series;
//		Serie s1,s2,s3;
//		Exercicio e1,e2,e3;
//		Treino t1, t2,t3;
//
//		e1 = er.recuperar(1);
//		e2 = er.recuperar(2);
//		e3 = er.recuperar(3);
//
//		t1 = tr.recuperar(1);
//		t2 = tr.recuperar(2);
//		t3 = tr.recuperar(3); 	
//
//
//		s1 = new Serie();
//		s1.setCodigo(1);
//		s1.setNome("Teste01");
//		s1.setRepeticoes(12);
//		s1.setExercicio(e1);
////		s1.setSerie(t1);
//
//		s2 = new Serie();
//		s2.setCodigo(2);
//		s2.setNome("Teste02");
//		s2.setRepeticoes(12);
//		s2.setExercicio(e2);
////		s2.setSerie(t2);
//
//		s3 = new Serie();
//		s3.setCodigo(3);
//		s2.setNome("Teste03");
//		s3.setRepeticoes(12);
//		s3.setExercicio(e3);
////		s3.setSerie(t3);
//
//
//		sr.adicionar(s1);
//		sr.adicionar(s2);
//		sr.adicionar(s3);
//
//		System.out.println("Listando series, todos...");
//		series = sr.recuperarTodos();
//		for (Serie serie : series) {
//			System.out.println(serie);
//		}
//
//		System.out.println("Listando series, todos...");
//		series = sr.recuperarTodos();
//		System.out.println("Recuperando series, id=1...");
//		s1 = sr.recuperar(1);
//		s1.setRepeticoes(15);;
//
//		System.out.println("Atualizando serie, id=1");
//		sr.atualizar(s1);
//
//		System.out.println("Listando series, todos...");
//		series = sr.recuperarTodos();
//		for (Serie serie : series) {
//			System.out.println(serie);
//		}
//
////		System.out.println("Listando series, todos...");
////		series = sr.recuperarTodos();
////		for (Serie serie : series) {
////			sr.remover(serie);
////		}
//
//
//		System.out.println("Listando series, todos...");
//		series = sr.recuperarTodos();
//		for (Serie serie : series) {
//			System.out.println(serie);
//		}
//
//
//		sr.encerrar();
//		er.encerrar();
//
//
//	}
//
//}