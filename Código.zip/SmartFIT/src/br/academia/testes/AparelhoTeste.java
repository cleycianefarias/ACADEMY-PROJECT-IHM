package br.academia.testes;

import java.util.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

public class AparelhoTeste {

	public static void main(String[] args) {
		AparelhoRepositorio ar = new AparelhoRepositorio();

		Aparelho a1,a2,a3;
		List<Aparelho> aparelhos;

		a1 = new Aparelho();
		a1.setCodigo(1);
		a1.setNome("Abdutora");
		a1.setDescricao("pernas");
		a1.setMarca("fitfit");

		a2 = new Aparelho();
		a2.setCodigo(2);
		a2.setNome("Peso");
		a2.setDescricao("32 kg");
		a2.setMarca("amotrei");

		a3 = new Aparelho();
		a3.setCodigo(3);
		a3.setNome("Bick");
		a3.setDescricao("Bicicleta rapida");
		a3.setMarca("caloi");


		System.out.println("Adicionando aparelhos...");
		ar.adicionar(a1);
		ar.adicionar(a2);
		ar.adicionar(a3);


		System.out.println("Listando aparelhos, todos...");
		aparelhos = ar.recuperarTodos();
		for (Aparelho aparelho : aparelhos) {
			System.out.println(aparelho);
		}

		System.out.println("Recuperando aparelho, id=3...");
		a3 = ar.recuperar(3);
		a3.setNome("Cadeira Flexora");
		a3.setDescricao("extensão dos joelhos");
		a3.setMarca("MP-197");

		System.out.println("Atualizando aparelho, id=3");
		ar.atualizar(a3);


		System.out.println("Recuperando aparelho, id=2...");		
		a2 = ar.recuperar(2);
		a2.setNome("Panturrilha");
		a2.setDescricao("Alongamento Panturrilha");
		a2.setMarca("APARELHO SMITH");

		System.out.println("Atualizando aluno, id=2");
		ar.atualizar(a2);


		System.out.println("Listando aparelho, todos...");
		aparelhos = ar.recuperarTodos();
		for (Aparelho aparelho : aparelhos) {
			System.out.println(aparelho);
		}

//		System.out.println("Removendo aparelhos...");
//		aparelhos = ar.recuperarTodos();
//		for (Aparelho aparelho : aparelhos) {
//			ar.remover(aparelho);
//		}

		System.out.println("Listando aparelhos, nenhum...");
		aparelhos = ar.recuperarTodos();
		for (Aparelho aparelho : aparelhos) {
			System.out.println(aparelho);
		}


		ar.encerrar();


	}

}