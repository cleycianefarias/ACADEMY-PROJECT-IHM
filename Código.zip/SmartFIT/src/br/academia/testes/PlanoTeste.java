//package br.academia.testes;
//
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//public class PlanoTeste {
//
//	public static void main(String[] args) {
//
//		PlanoRepositorio pr = new PlanoRepositorio();
//		List<Plano> Planos;
//
//		Plano p1, p2, p3;
//
//		AlunoRepositorio ar = new AlunoRepositorio();
//		FuncionarioRepositorio fr = new FuncionarioRepositorio();
//		Aluno a1, a2, a3;
//		Funcionario f1, f2, f3;
//
//		a1 = ar.recuperar(1);
//		f1 = fr.recuperar(1);
//
//		a2 = ar.recuperar(2);
//		f2 = fr.recuperar(2);
//
//		a3 = ar.recuperar(3);
//		f3 = fr.recuperar(3);
//
//		p1 = new Plano();
//		p1.setCodigo(1);
//		p1.setNome("Abdutora");
//		p1.setDescricao("pernas");
//		p1.setValor(500);
//
//
//		p2 = new Plano();
//		p2.setCodigo(2);
//		p2.setNome("Abdutora");
//		p2.setDescricao("pernas");
//		p2.setValor(500);
//
//
//		p3 = new Plano();
//		p3.setCodigo(3);
//		p3.setNome("Abdutora");
//		p3.setDescricao("pernas");
//		p3.setValor(500);
//
//		System.out.println("Adicionando Planos...");
//		pr.adicionar(p1);
//		pr.adicionar(p2);
//		pr.adicionar(p3);
//
//		System.out.println("Listando Planos, todos...");
//		Planos = pr.recuperarTodos();
//		for (Plano Plano : Planos) {
//			System.out.println(Plano);
//		}
//		System.out.println("Recuperando Plano, id=1...");
//		p1 = pr.recuperar(1);
//		p1.setNome("a");
//
//		System.out.println("Atualizando Plano, id=1");
//		pr.atualizar(p1);
//
//		System.out.println("Listando Planos, todos...");
//		Planos = pr.recuperarTodos();
//		for (Plano Plano : Planos) {
//			System.out.println(Plano);
//		}
//
//		System.out.println("Removendo Planos, todos...");
//		Planos = pr.recuperarTodos();
//		for (Plano Plano : Planos) {
//			pr.remover(Plano);
//		}
//
//		System.out.println("Listando Planos, todos...");
//		Planos = pr.recuperarTodos();
//		for (Plano Plano : Planos) {
//			System.out.println(Plano);
//		}
//
//		pr.encerrar();
//		ar.encerrar();
//		fr.encerrar();
//
//	}
//
//}