//package br.academia.testes;
//import java.util.*;
//
//import br.academia.entidades.*;
//import br.academia.repositorios.*;
//
//
//
//public class PagamentoTeste {
//
//	public static void main(String[] args) {
//
//		PlanoRepositorio pr = new PlanoRepositorio();
//		List<Pagamento> pagamentos;
//
//		Pagamento pg1,pg2,pg3;
//		PagDinheiro pd1;
//		AlunoRepositorio ar = new AlunoRepositorio();
//		FuncionarioRepositorio fr = new FuncionarioRepositorio();
//		PagamentoRepositorio pgr = new PagamentoRepositorio();
//		Aluno a1,a2,a3;
//		Plano p1,p2,p3;
//
//		a1 = ar.recuperar(1);
//		p1 = pr.recuperar(1);
//
//		a2 = ar.recuperar(2);
//		p2 = pr.recuperar(2);
//
//		a3 = ar.recuperar(3);
//		p3 = pr.recuperar(3);
//
//
//
//		Date data1 = new Date(2018, 4, 1);
//		pg1 = new PagCartao();
//		pg1.setCodigo(1);
//		pg1.setData(data1);
//		pg1.setValor(500);
//		pg1.setAluno(a1);
//		((PagCartao) pg1).setNumeroCartao(125556554);
//		
//
//		Date data2 = new Date(2018, 6, 1);
//		pg2 = new PagDinheiro();
//		pg2.setCodigo(2);
//		pg2.setData(data2);
//		pg2.setValor(540);
//		pg2.setAluno(a2);
//		
//		((PagDinheiro) pg2).setValorRecebido(12569);
//		System.out.println(pg2.getClass().getMethods().toString());
//	
//		
//
////		Date data3 = new Date(2018, 10, 11);
////		pg3 = new Pagamento();
////		pg3.setCodigo(3);
////		pg3.setData(data3);
////		pg3.setPlano(p3);
////		pg3.setValor(140);
////		pg3.setAluno(a3);
//
//
//		System.out.println("Adicionando pagamentos...");
//		pgr.adicionar(pg1);
//		pgr.adicionar(pg2);
//
//
//		System.out.println("Listando pagamentos, todos...");
//		
//		
//		pagamentos = pgr.recuperarTodos();
//		System.out.println("Recuperando pagamentos, id=1...");
//		pg1 = pgr.recuperar(1);
//		pg1.setValor(652);
//
//		System.out.println("Atualizando pagamentos, id=1");
//		pgr.atualizar(pg1);
//		
//
//		System.out.println("Listando pagamentos, todos...");
//		pagamentos = pgr.recuperarTodos();
//		for (Pagamento pagamento : pagamentos) {
//			System.out.println(pagamento);
//		}
//
////		System.out.println("Remover pagamentos, todos...");
////		pagamentos = pgr.recuperarTodos();
////		for (Pagamento pagamento : pagamentos) {
////			pgr.remover(pagamento);
////		}
////
////
////		System.out.println("Listando pagamentos, todos...");
////		pagamentos = pgr.recuperarTodos();
////		for (Pagamento pagamento : pagamentos) {
////			System.out.println(pagamento);
////		}
//
//
//		pr.encerrar();
//		ar.encerrar();
//		fr.encerrar();
//		pgr.encerrar();
//
//
//	}
//
//}