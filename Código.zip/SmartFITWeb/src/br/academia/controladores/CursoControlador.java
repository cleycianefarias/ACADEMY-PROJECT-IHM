package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="cursoControlador")
@SessionScoped
public class CursoControlador {
	private CursoRepositorio cr;
	private List<Curso> cursos;
	private String chaveNome="";
	private Curso curso;
	
	public CursoControlador() {
		cr = new CursoRepositorio();
	}
	
	public Curso getCurso() {
		return curso;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public List<Curso> getCursos() {
		cursos = cr.recuperarTodosPorNomeContendo(chaveNome);
		return cursos;
	}
	
	// Métodos de controle da interface
	public String incluir() {
		curso = new Curso();
		return "cursoInclusao";
	}

	public String editar(Curso curso) {
		this.curso = curso;
		return "cursoEdicao";
	}

	public String excluir(Curso curso) {
		this.curso = curso;
		return "cursoExclusao";
	}

	// Métodos de controle do modelo
	public String adicionar() {
		cr.adicionar(curso);
		return "cursoListagem";
	}
	
	public String atualizar() {
		cr.atualizar(curso);
		return "cursoListagem";
	}

	public String remover() {
		cr.remover(curso);
		return "cursoListagem";
	}
	
}
