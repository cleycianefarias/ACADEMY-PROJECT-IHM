package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="alunoControlador")
@SessionScoped
public class AlunoControlador {

	private List<Aluno> alunos;
	private AlunoRepositorio ar;
	private CursoRepositorio cr;
	private Aluno aluno;
	private int cursoCodigo;
	private String chaveNome="";
	
	public Aluno getAluno() {
		return aluno;
	}

	public int getCursoCodigo() {
		return cursoCodigo;
	}

	public void setCursoCodigo(int cursoCodigo) {
		this.cursoCodigo = cursoCodigo;
	}

	public AlunoControlador() {
		ar = new AlunoRepositorio();
		cr = new CursoRepositorio();
	}

	public List<Aluno> getAlunos() {
		alunos = ar.recuperarTodosPorNomeContendo(chaveNome);
		return alunos;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		aluno = new Aluno();
		return "alunoInclusao";
	}
	
	public String adicionar() {
		aluno.setCurso(cr.recuperar(cursoCodigo));
		ar.adicionar(aluno);
		return "alunoListagem";
	}
	
	public String editar(Aluno aluno) {
		this.aluno = aluno;
		cursoCodigo = aluno.getCurso().getCodigo();
		return "alunoEdicao";
	}
	
	public String atualizar() {
		aluno.setCurso(cr.recuperar(cursoCodigo));
		ar.atualizar(aluno);
		return "alunoListagem";
	}
	
	public String excluir(Aluno aluno) {
		this.aluno = aluno;
		cursoCodigo = aluno.getCurso().getCodigo();
		return "alunoExclusao";
	}
	
	public String remover() {
		ar.remover(aluno);
		return "alunoListagem";
	}
}
