package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="exercicioControlador")
@SessionScoped
public class ExercicioControlador {

	private List<Exercicio> exercicios;
	private ExercicioRepositorio ar;
	private AparelhoRepositorio cr;
	private Exercicio exercicio;
	private int aparelhoCodigo;
	private String chaveNome="";
	
	public Exercicio getExercicio() {
		return exercicio;
	}

	public int getAparelhoCodigo() {
		return aparelhoCodigo;
	}

	public void setAparelhoCodigo(int aparelhoCodigo) {
		this.aparelhoCodigo = aparelhoCodigo;
	}

	public ExercicioControlador() {
		ar = new ExercicioRepositorio();
		cr = new AparelhoRepositorio();
	}

	public List<Exercicio> getExercicios() {
		exercicios = ar.recuperarTodosPorNomeContendo(chaveNome);
		return exercicios;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		exercicio = new Exercicio();
		return "exercicioInclusao";
	}
	
	public String adicionar() {
		exercicio.setAparelho(cr.recuperar(aparelhoCodigo));
		ar.adicionar(exercicio);
		return "exercicioListagem";
	}
	
	public String editar(Exercicio exercicio) {
		this.exercicio = exercicio;
		aparelhoCodigo = exercicio.getAparelho().getCodigo();
		return "exercicioEdicao";
	}
	
	public String atualizar() {
		exercicio.setAparelho(cr.recuperar(aparelhoCodigo));
		ar.atualizar(exercicio);
		return "exercicioListagem";
	}
	
	public String excluir(Exercicio exercicio) {
		this.exercicio = exercicio;
		aparelhoCodigo = exercicio.getAparelho().getCodigo();
		return "exercicioExclusao";
	}
	
	public String remover() {
		ar.remover(exercicio);
		return "exercicioListagem";
	}
}
