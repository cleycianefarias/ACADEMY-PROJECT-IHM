package br.academia.controladores;
import java.util.*;
import javax.faces.bean.*;
import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="treinoControlador")
@SessionScoped
public class TreinoControlador {

	private List<Treino> treinos;
	private TreinoRepositorio ar;
	private AlunoRepositorio cr;
	private FuncionarioRepositorio fr;
	private Treino treino;
	private long alunoMatricula;
	private long funcionarioMatricula;
	private String chaveNome="";
	
	public Treino getTreino() {
		return treino;
	}

	public long getAlunoMatricula() {
		return alunoMatricula;
	}

	public void setAlunoMatricula(long alunoMatricula) {
		this.alunoMatricula = alunoMatricula;
	}
	public long getFuncionarioMatricula() {
		return funcionarioMatricula;
	}

	public void setFuncionarioMatricula(long funcionarioMatricula) {
		this.funcionarioMatricula = funcionarioMatricula;
	}

	public TreinoControlador() {
		ar = new TreinoRepositorio();
		cr = new AlunoRepositorio();
		fr = new FuncionarioRepositorio();
	}

	public List<Treino> getTreinos() {
		treinos = ar.recuperarTodosPorNomeContendo(chaveNome);
		return treinos;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		treino = new Treino();
		return "treinoInclusao";
	}
	
	public String adicionar() {
		treino.setAluno(cr.recuperar(alunoMatricula));
		treino.setFuncionario(fr.recuperar(funcionarioMatricula));
		ar.adicionar(treino);
		return "treinoListagem";
	}
	
	public String editar(Treino treino) {
		this.treino = treino;
		alunoMatricula = treino.getAluno().getMatricula();
		funcionarioMatricula = treino.getFuncionario().getMatricula();
		return "treinoEdicao";
	}
	
	public String atualizar() {
		treino.setAluno(cr.recuperar(alunoMatricula));
		treino.setFuncionario(fr.recuperar(funcionarioMatricula));
		ar.atualizar(treino);
		return "treinoListagem";
	}
	
	public String excluir(Treino treino) {
		this.treino = treino;
		alunoMatricula = treino.getAluno().getMatricula();
		funcionarioMatricula = treino.getFuncionario().getMatricula();
		return "treinoExclusao";
	}
	
	public String remover() {
		ar.remover(treino);
		return "treinoListagem";
	}
}
