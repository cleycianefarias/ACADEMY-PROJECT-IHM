package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="cadastroControlador")
@SessionScoped
public class CadastroControlador {

	private List<Cadastro> cadastros;
	private CadastroRepositorio ar;
	private AlunoRepositorio cr;
	private FuncionarioRepositorio fr;
	private PlanoRepositorio pr;
	private Cadastro cadastro;
	private long alunoMatricula, funcionarioMatricula;
	private int planoCodigo;
	private String chaveNome="";
	
	public Cadastro getCadastro() {
		return cadastro;
	}

	public long getAlunoMatricula() {
		return alunoMatricula;
	}

	public void setAlunoMatricula(long alunoMatricula) {
		this.alunoMatricula = alunoMatricula;
	}
	
	public long getFuncionarioMatricula() {
		return funcionarioMatricula;
	}

	public void setFuncionarioMatricula(long funcionarioMatricula) {
		this.funcionarioMatricula = funcionarioMatricula;
	}
	public int getPlanoCodigo() {
		return planoCodigo;
	}

	public void setPlanoCodigo(int planoCodigo) {
		this.planoCodigo = planoCodigo;
	}

	public CadastroControlador() {
		ar = new CadastroRepositorio();
		cr = new AlunoRepositorio();
		pr = new PlanoRepositorio();
		fr = new FuncionarioRepositorio();
	}

	public List<Cadastro> getCadastros() {
		cadastros = ar.recuperarTodosPorNomeContendo(chaveNome);
		return cadastros;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		cadastro = new Cadastro();
		return "cadastroInclusao";
	}
	
	public String adicionar() {
		cadastro.setAluno(cr.recuperar(alunoMatricula));
		cadastro.setFuncionario(fr.recuperar(funcionarioMatricula));
		cadastro.setPlano(pr.recuperar(planoCodigo));
		ar.adicionar(cadastro);
		return "cadastroListagem";
	}
	
	public String editar(Cadastro cadastro) {
		this.cadastro = cadastro;
		alunoMatricula = cadastro.getAluno().getMatricula();
		planoCodigo = cadastro.getPlano().getCodigo();
		funcionarioMatricula = cadastro.getFuncionario().getMatricula();
		
		return "cadastroEdicao";
	}
	
	public String atualizar() {
		cadastro.setAluno(cr.recuperar(alunoMatricula));
		cadastro.setPlano(pr.recuperar(planoCodigo));
		cadastro.setFuncionario(fr.recuperar(funcionarioMatricula));
		ar.atualizar(cadastro);
		return "cadastroListagem";
	}
	
	public String excluir(Cadastro cadastro) {
		this.cadastro = cadastro;
		alunoMatricula = cadastro.getAluno().getMatricula();
		funcionarioMatricula = cadastro.getFuncionario().getMatricula();
		planoCodigo = cadastro.getPlano().getCodigo();
		return "cadastroExclusao";
	}
	
	public String remover() {
		ar.remover(cadastro);
		return "cadastroListagem";
	}
}