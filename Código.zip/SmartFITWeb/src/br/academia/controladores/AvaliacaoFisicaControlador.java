package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="avaliacaoFisicaControlador")
@SessionScoped
public class AvaliacaoFisicaControlador {

	private List<AvaliacaoFisica> avaliacoesFisicas;
	private AvaliacaoFisicaRepositorio ar;
	private AlunoRepositorio cr;
	private FuncionarioRepositorio fr;
	private ProfessorRepositorio pr;
	private AvaliacaoFisica avaliacaoFisica;
	private long alunoMatricula, funcionarioMatricula, professorMatricula;
	private String chaveNome="";
	
	public AvaliacaoFisica getAvaliacaoFisica() {
		return avaliacaoFisica;
	}

	public long getAlunoMatricula() {
		return alunoMatricula;
	}

	public void setAlunoMatricula(long alunoMatricula) {
		this.alunoMatricula = alunoMatricula;
	}
	public long getFuncionarioMatricula() {
		return funcionarioMatricula;
	}

	public void setFuncionarioMatricula(long funcionarioMatricula) {
		this.funcionarioMatricula = funcionarioMatricula;
	}
	public long getProfessorMatricula() {
		return professorMatricula;
	}

	public void setProfessorMatricula(long professorMatricula) {
		this.professorMatricula = professorMatricula;
	}

	public AvaliacaoFisicaControlador() {
		ar = new AvaliacaoFisicaRepositorio();
		cr = new AlunoRepositorio();
		pr = new ProfessorRepositorio();
		fr = new FuncionarioRepositorio();
	}

	public List<AvaliacaoFisica> getAvaliacoesFisicas() {
		avaliacoesFisicas = ar.recuperarTodosPorNomeContendo(chaveNome);
		return avaliacoesFisicas;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		avaliacaoFisica = new AvaliacaoFisica();
		return "avaliacaoFisicaInclusao";
	}
	
	public String adicionar() {
		avaliacaoFisica.setAluno(cr.recuperar(alunoMatricula));
		avaliacaoFisica.setFuncionario(fr.recuperar(funcionarioMatricula));
		avaliacaoFisica.setProfessor(pr.recuperar(professorMatricula));
		ar.adicionar(avaliacaoFisica);
		return "avaliacaoFisicaListagem";
	}
	
	public String editar(AvaliacaoFisica avaliacaoFisica) {
		this.avaliacaoFisica = avaliacaoFisica;
		alunoMatricula = avaliacaoFisica.getAluno().getMatricula();
		professorMatricula = avaliacaoFisica.getProfessor().getMatricula();
		funcionarioMatricula = avaliacaoFisica.getFuncionario().getMatricula();
		
		return "avaliacaoFisicaEdicao";
	}
	
	public String atualizar() {
		avaliacaoFisica.setAluno(cr.recuperar(alunoMatricula));
		avaliacaoFisica.setProfessor(pr.recuperar(professorMatricula));
		avaliacaoFisica.setFuncionario(fr.recuperar(funcionarioMatricula));
		ar.atualizar(avaliacaoFisica);
		return "avaliacaoFisicaListagem";
	}
	
	public String excluir(AvaliacaoFisica avaliacaoFisica) {
		this.avaliacaoFisica = avaliacaoFisica;
		alunoMatricula = avaliacaoFisica.getAluno().getMatricula();
		funcionarioMatricula = avaliacaoFisica.getFuncionario().getMatricula();
		professorMatricula = avaliacaoFisica.getProfessor().getMatricula();
		return "avaliacaoFisicaExclusao";
	}
	
	public String remover() {
		ar.remover(avaliacaoFisica);
		return "avaliacaoFisicaListagem";
	}
}
