package br.academia.controladores;
import java.util.*;
import javax.faces.bean.*;
import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="pagamentoDinheiroControlador")
@SessionScoped
public class PagamentoDinheiroControlador {

	private List<PagamentoDinheiro> pagamentos;
	private PagamentoDinheiroRepositorio ar;
	private AlunoRepositorio cr;
	private CadastroRepositorio fr;
	private PagamentoDinheiro pagamentoDinheiro;
	private long alunoMatricula;
	private long cadastroMatricula;
	private String chaveNome="";
	
	public PagamentoDinheiro getPagamentoDinheiro() {
		return pagamentoDinheiro;
	}

	public long getAlunoMatricula() {
		return alunoMatricula;
	}

	public void setAlunoMatricula(long alunoMatricula) {
		this.alunoMatricula = alunoMatricula;
	}
	public long getCadastroMatricula() {
		return cadastroMatricula;
	}

	public void setCadastroMatricula(long cadastroMatricula) {
		this.cadastroMatricula = cadastroMatricula;
	}

	public PagamentoDinheiroControlador() {
		ar = new PagamentoDinheiroRepositorio();
		cr = new AlunoRepositorio();
		fr = new CadastroRepositorio();
	}

	public List<PagamentoDinheiro> getPagamentoDinheiros() {
		pagamentos = ar.recuperarTodosPorNomeContendo(chaveNome);
		return pagamentos;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		pagamentoDinheiro = new PagamentoDinheiro();
		return "pagamentoDinheiroInclusao";
	}
	
	public String adicionar() {
		pagamentoDinheiro.setAluno(cr.recuperar(alunoMatricula));
		pagamentoDinheiro.setCadastro(fr.recuperar(cadastroMatricula));
		ar.adicionar(pagamentoDinheiro);
		return "pagamentoListagem";
	}
	
	public String editar(PagamentoDinheiro pagamento) {
		this.pagamentoDinheiro = pagamento;
		alunoMatricula = pagamento.getAluno().getMatricula();
		cadastroMatricula = pagamento.getCadastro().getCodigo();
		return "pagamentoEdicao";
	}
	
	public String atualizar() {
		pagamentoDinheiro.setAluno(cr.recuperar(alunoMatricula));
		pagamentoDinheiro.setCadastro(fr.recuperar(cadastroMatricula));
		ar.atualizar(pagamentoDinheiro);
		return "pagamentoListagem";
	}
	
	public String excluir(PagamentoDinheiro pagamento) {
		this.pagamentoDinheiro = pagamento;
		alunoMatricula = pagamento.getAluno().getMatricula();
		cadastroMatricula = pagamento.getCadastro().getCodigo();
		return "pagamentoExclusao";
	}
	
	public String remover() {
		ar.remover(pagamentoDinheiro);
		return "pagamentoListagem";
	}
}