package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="planoControlador")
@SessionScoped
public class PlanoControlador {

	private List<Plano> planos;
	private PlanoRepositorio ar;
	private Plano plano;
	private String chaveNome="";
	
	public Plano getPlano() {
		return plano;
	}

	public PlanoControlador() {
		ar = new PlanoRepositorio();
	}

	public List<Plano> getPlanos() {
		planos = ar.recuperarTodosPorNomeContendo(chaveNome);
		return planos;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		plano = new Plano();
		return "planoInclusao";
	}
	
	public String adicionar() {
		ar.adicionar(plano);
		return "planoListagem";
	}
	
	public String editar(Plano plano) {
		this.plano = plano;
		return "planoEdicao";
	}
	
	public String atualizar() {
		ar.atualizar(plano);
		return "planoListagem";
	}
	
	public String excluir(Plano plano) {
		this.plano = plano;
		return "planoExclusao";
	}
	
	public String remover() {
		ar.remover(plano);
		return "planoListagem";
	}
}
