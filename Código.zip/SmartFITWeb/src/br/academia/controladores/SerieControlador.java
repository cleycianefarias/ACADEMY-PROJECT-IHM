package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="serieControlador")
@SessionScoped
public class SerieControlador {

	private List<Serie> series;
	private SerieRepositorio ar;
	private TreinoRepositorio tr;
	private ExercicioRepositorio cr;
	private Serie serie;
	private int exercicioCodigo, treinoCodigo;
	private String chaveNome="";
	
	public Serie getSerie() {
		return serie;
	}

	public int getExercicioCodigo() {
		return exercicioCodigo;
	}

	public void setExercicioCodigo(int exercicioCodigo) {
		this.exercicioCodigo = exercicioCodigo;
	}
	public int getTreinoCodigo() {
		return treinoCodigo;
	}

	public void setTreinoCodigo(int treinoCodigo) {
		this.treinoCodigo = treinoCodigo;
	}


	public SerieControlador() {
		ar = new SerieRepositorio();
		cr = new ExercicioRepositorio();
		tr = new TreinoRepositorio();
	}

	public List<Serie> getSeries() {
		series = ar.recuperarTodosPorNomeContendo(chaveNome);
		return series;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		serie = new Serie();
		return "serieInclusao";
	}
	
	public String adicionar() {
		serie.setExercicio(cr.recuperar(exercicioCodigo));
		serie.setTreino(tr.recuperar(treinoCodigo));
		ar.adicionar(serie);
		return "serieListagem";
	}
	
	public String editar(Serie serie) {
		this.serie = serie;
		exercicioCodigo = serie.getExercicio().getCodigo();
		treinoCodigo = serie.getTreino().getCodigo();
		return "serieEdicao";
	}
	
	public String atualizar() {
		serie.setExercicio(cr.recuperar(exercicioCodigo));
		serie.setTreino(tr.recuperar(treinoCodigo));
		ar.atualizar(serie);
		return "serieListagem";
	}
	
	public String excluir(Serie serie) {
		this.serie = serie;
		exercicioCodigo = serie.getExercicio().getCodigo();
		treinoCodigo = serie.getTreino().getCodigo();
		return "serieExclusao";
	}
	
	public String remover() {
		ar.remover(serie);
		return "serieListagem";
	}
}
