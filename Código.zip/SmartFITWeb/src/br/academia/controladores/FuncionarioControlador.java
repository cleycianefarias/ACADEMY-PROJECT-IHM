package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="funcionarioControlador")
@SessionScoped
public class FuncionarioControlador {

	private List<Funcionario> funcionarioes;
	private FuncionarioRepositorio pr;
	private Funcionario funcionario;
	private int cursoCodigo;
	private String chaveNome="";
	
	public Funcionario getFuncionario() {
		return funcionario;
	}


	public FuncionarioControlador() {
		pr = new FuncionarioRepositorio();
	}

	public List<Funcionario> getFuncionarios() {
		funcionarioes = pr.recuperarTodosPorNomeContendo(chaveNome);
		return funcionarioes;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		funcionario = new Funcionario();
		return "funcionarioInclusao";
	}
	
	public String adicionar() {
		pr.adicionar(funcionario);
		return "funcionarioListagem";
	}
	
	public String editar(Funcionario funcionario) {
		this.funcionario = funcionario;
		return "funcionarioEdicao";
	}
	
	public String atualizar() {
		pr.atualizar(funcionario);
		return "funcionarioListagem";
	}
	
	public String excluir(Funcionario funcionario) {
		this.funcionario = funcionario;
		return "funcionarioExclusao";
	}
	
	public String remover() {
		pr.remover(funcionario);
		return "funcionarioListagem";
	}
}
