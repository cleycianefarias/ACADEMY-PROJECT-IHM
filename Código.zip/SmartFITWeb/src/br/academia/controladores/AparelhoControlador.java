package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="aparelhoControlador")
@SessionScoped
public class AparelhoControlador {

	private List<Aparelho> aparelhos;
	private AparelhoRepositorio pr;
	private Aparelho aparelho;
	private String chaveNome="";
	
	public Aparelho getAparelho() {
		return aparelho;
	}


	public AparelhoControlador() {
		pr = new AparelhoRepositorio();
	}

	public List<Aparelho> getAparelhos() {
		aparelhos = pr.recuperarTodosPorNomeContendo(chaveNome);
		return aparelhos;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		aparelho = new Aparelho();
		return "aparelhoInclusao";
	}
	
	public String adicionar() {
		pr.adicionar(aparelho);
		return "aparelhoListagem";
	}
	
	public String editar(Aparelho aparelho) {
		this.aparelho = aparelho;
		return "aparelhoEdicao";
	}
	
	public String atualizar() {
		pr.atualizar(aparelho);
		return "aparelhoListagem";
	}
	
	public String excluir(Aparelho aparelho) {
		this.aparelho = aparelho;
		return "aparelhoExclusao";
	}
	
	public String remover() {
		pr.remover(aparelho);
		return "aparelhoListagem";
	}
}
