package br.academia.controladores;

import java.util.*;
import javax.faces.bean.*;

import br.academia.entidades.*;
import br.academia.repositorios.*;

@ManagedBean(name="professorControlador")
@SessionScoped
public class ProfessorControlador {

	private List<Professor> professores;
	private ProfessorRepositorio pr;
	private CursoRepositorio cr;
	private Professor professor;
	private int cursoCodigo;
	private String chaveNome="";
	
	public Professor getProfessor() {
		return professor;
	}


	public ProfessorControlador() {
		pr = new ProfessorRepositorio();
		cr = new CursoRepositorio();
	}

	public List<Professor> getProfessores() {
		professores = pr.recuperarTodosPorNomeContendo(chaveNome);
		return professores;
	}

	public String getChaveNome() {
		return chaveNome;
	}

	public void setChaveNome(String chaveNome) {
		this.chaveNome = chaveNome;
	}

	public String incluir() {
		professor = new Professor();
		return "professorInclusao";
	}
	
	public String adicionar() {
		pr.adicionar(professor);
		return "professorListagem";
	}
	
	public String editar(Professor professor) {
		this.professor = professor;
		return "professorEdicao";
	}
	
	public String atualizar() {
		pr.atualizar(professor);
		return "professorListagem";
	}
	
	public String excluir(Professor professor) {
		this.professor = professor;
		return "professorExclusao";
	}
	
	public String remover() {
		pr.remover(professor);
		return "professorListagem";
	}
}
